function irGestionPersonal() {
    window.location.href = "gestion-personal.html";
}

function irRegistrarPersonal() {
    window.location.href = "registrar-personal.html";
}

function irGestionPersonal() {
    window.location.href = "gestion-personal.html";
}

function irRegistrarPersonal() {
    window.location.href = "registrar-personal.html";
}

// Nueva función para regresar al Login/Index
function cerrarSesion() {
    window.location.href = "index.html";
}