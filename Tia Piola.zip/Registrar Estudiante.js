// ==========================
// PREVISUALIZAR IMAGEN
// ==========================
const btnSubir = document.getElementById("btnSubir");
const inputImagen = document.getElementById("inputImagen");
const previewImagen = document.getElementById("previewImagen");

if (btnSubir) {
    btnSubir.addEventListener("click", () => {
        inputImagen.click();
    });
}

if (inputImagen) {
    inputImagen.addEventListener("change", (e) => {
        const archivo = e.target.files[0];

        if (archivo) {
            const lector = new FileReader();

            lector.onload = function(evento) {
                previewImagen.src = evento.target.result;
            };

            lector.readAsDataURL(archivo);
        }
    });
}

// ==========================
// CAPTURAR FOTO
// ==========================
const btnCapturar = document.getElementById("btnCapturar");

if (btnCapturar) {
    btnCapturar.addEventListener("click", () => {
        alert("La función de cámara será integrada posteriormente.");
    });
}

// ==========================
// BOTÓN CANCELAR Y REDIRIGIR
// ==========================
const btnCancelar = document.querySelector(".cancelar");

if (btnCancelar) {
    btnCancelar.addEventListener("click", () => {
        const confirmar = confirm("¿Deseas cancelar y regresar al Módulo de Estudiantes?");

        if (confirmar) {
            window.location.href = "modulo-estudiantes.html";
        }
    });
}

// ==========================
// GUARDAR ESTUDIANTE Y REDIRIGIR
// ==========================
const formulario = document.getElementById("formEstudiante");

if (formulario) {
    formulario.addEventListener("submit", (e) => {
        e.preventDefault();

        const nombreInput = document.querySelector('.datos-personales input[type="text"]');
        const nombre = nombreInput ? nombreInput.value : "";

        if (nombre.trim() === "") {
            alert("Debes ingresar el nombre completo.");
            return;
        }

        alert("¡Estudiante registrado correctamente!");

        // Resetea el formulario
        formulario.reset();
        if (previewImagen) {
            previewImagen.src = "Logo/user-placeholder.png";
        }

        // REDIRIGE AL MÓDULO DE ESTUDIANTES
        window.location.href = "Módulo de Estudiantes.html";
    });
}

// ==========================
// NOTIFICACIÓN
// ==========================
const notificacion = document.querySelector(".notificacion");

if (notificacion) {
    notificacion.addEventListener("click", () => {
        alert("No tienes notificaciones nuevas.");
    });
}

// ==========================
// CERRAR SESIÓN
// ==========================
const cerrarSesion = document.querySelector(".cerrar-sesion");

if (cerrarSesion) {
    cerrarSesion.addEventListener("click", () => {
        const salir = confirm("¿Deseas cerrar sesión?");

        if (salir) {
            window.location.href = "index.html";
        }
    });
}