// ==========================
// MOSTRAR / OCULTAR CONTRASEÑA
// ==========================

const passwordInput = document.getElementById("password");
const iconoOjo = document.querySelector(".password-box i");

if(iconoOjo){

    iconoOjo.addEventListener("click", () => {

        if(passwordInput.type === "password"){

            passwordInput.type = "text";
            iconoOjo.classList.remove("fa-eye");
            iconoOjo.classList.add("fa-eye-slash");

        }else{

            passwordInput.type = "password";
            iconoOjo.classList.remove("fa-eye-slash");
            iconoOjo.classList.add("fa-eye");

        }

    });

}

// ==========================
// PROFESOR / ADMINISTRADOR
// ==========================

const profesorRadio =
document.querySelector('input[value="profesor"]');

const adminRadio =
document.querySelector('input[value="administrador"]');

const profesorBox =
document.querySelector(".profesor-box");

const adminBox =
document.querySelector(".admin-box");

function actualizarTipoUsuario(){

    if(profesorRadio.checked){

        profesorBox.style.opacity = "1";
        adminBox.style.opacity = "0.5";

    }else{

        profesorBox.style.opacity = "0.5";
        adminBox.style.opacity = "1";

    }

}

profesorRadio.addEventListener(
"change",
actualizarTipoUsuario
);

adminRadio.addEventListener(
"change",
actualizarTipoUsuario
);

actualizarTipoUsuario();

// ==========================
// CANCELAR
// ==========================

const btnCancelar =
document.querySelector(".cancelar");

btnCancelar.addEventListener("click", () => {

    const confirmar = confirm(
        "¿Deseas limpiar todos los datos?"
    );

    if(confirmar){

        document
        .getElementById("formPersonal")
        .reset();

        actualizarTipoUsuario();

    }

});

// ==========================
// GUARDAR PERSONAL
// ==========================

const formulario =
document.getElementById("formPersonal");

formulario.addEventListener("submit", (e) => {

    e.preventDefault();

    const nombre =
    document.querySelector(
    'input[type="text"]'
    ).value;

    if(nombre.trim() === ""){

        alert(
        "Debes ingresar el nombre completo."
        );

        return;
    }

    alert(
    "Personal registrado correctamente."
    );

    formulario.reset();

    actualizarTipoUsuario();

});