// ===============================
// NOTIFICACIONES
// ===============================

const btnNotificacion = document.querySelector(".notificacion");

if(btnNotificacion){
    btnNotificacion.addEventListener("click", () => {
        alert("No tienes nuevas notificaciones.");
    });

    btnNotificacion.addEventListener("mouseenter", () => {
        btnNotificacion.style.transform = "scale(1.15) rotate(15deg)";
    });

    btnNotificacion.addEventListener("mouseleave", () => {
        btnNotificacion.style.transform = "scale(1) rotate(0deg)";
    });
}

// ===============================
// CERRAR SESIÓN
// ===============================

const btnLogout = document.querySelector(".cerrar-sesion") || document.querySelector(".logout");

if(btnLogout){
    btnLogout.addEventListener("click", (e) => {
        e.preventDefault();
        const confirmar = confirm("¿Desea cerrar sesión?");

        if(confirmar){
            window.location.href = "index.html";
        }
    });
}

// ===============================
// IR A GESTIÓN ESTUDIANTES
// ===============================

function irBuscarEstudiantes(){
    window.location.href = "control-busqueda-estudiantes.html";
}

// ===============================
// IR A REGISTRAR ESTUDIANTE
// ===============================

function irRegistrarEstudiante(){
    window.location.href = "Registrar Estudiante.html";
}

// ===============================
// EFECTO TARJETAS
// ===============================

const tarjetas = document.querySelectorAll(".card");

tarjetas.forEach(card => {
    card.addEventListener("mouseenter", () => {
        card.style.transform = "translateY(-10px)";
    });

    card.addEventListener("mouseleave", () => {
        card.style.transform = "translateY(0px)";
    });
});

// ===============================
// ANIMACIÓN AL CARGAR
// ===============================

window.addEventListener("load", () => {
    tarjetas.forEach((card, index) => {
        card.style.opacity = "0";
        card.style.transform = "translateY(30px)";

        setTimeout(() => {
            card.style.transition = "all .5s ease";
            card.style.opacity = "1";
            card.style.transform = "translateY(0px)";
        }, index * 250);
    });
});

// ===============================
// EFECTO LOGO
// ===============================

const logo = document.querySelector(".logo img");

if(logo){
    logo.addEventListener("mouseenter", () => {
        logo.style.transform = "rotate(10deg) scale(1.1)";
    });

    logo.addEventListener("mouseleave", () => {
        logo.style.transform = "rotate(0deg) scale(1)";
    });
}