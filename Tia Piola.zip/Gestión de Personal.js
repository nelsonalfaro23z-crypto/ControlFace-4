// ===================================
// CONTROLFACE - GESTIÓN DE PERSONAL
// ===================================

document.addEventListener("DOMContentLoaded", () => {

    // ===================================
    // BUSCADOR + FILTRO
    // ===================================

    const buscador = document.getElementById("busqueda");
    const filtroCargo = document.getElementById("filtroCargo");

    function actualizarTabla() {

        const textoBusqueda =
            buscador ? buscador.value.toLowerCase() : "";

        const cargoSeleccionado =
            filtroCargo ? filtroCargo.value.toLowerCase() : "todos";

        const filas =
            document.querySelectorAll("#tablaPersonal tr");

        filas.forEach(fila => {

            const nombre =
                fila.cells[2].textContent.toLowerCase();

            const cargo =
                fila.cells[3].textContent.toLowerCase();

            const correo =
                fila.cells[4].textContent.toLowerCase();

            const coincideBusqueda =
                nombre.includes(textoBusqueda) ||
                correo.includes(textoBusqueda);

            const coincideCargo =
                cargoSeleccionado === "todos" ||
                cargo.includes(cargoSeleccionado);

            fila.style.display =
                (coincideBusqueda && coincideCargo)
                ? ""
                : "none";

        });

    }

    if (buscador) {
        buscador.addEventListener("keyup", actualizarTabla);
    }

    if (filtroCargo) {
        filtroCargo.addEventListener("change", actualizarTabla);
    }

    // ===================================
    // EDITAR
    // ===================================

    document.querySelectorAll(".editar").forEach(btn => {

        btn.addEventListener("click", () => {

            let fila = btn.closest("tr");

            let nombreActual =
                fila.cells[2].innerText;

            let correoActual =
                fila.cells[4].innerText;

            let nuevoNombre = prompt(
                "Editar nombre:",
                nombreActual
            );

            if (
                nuevoNombre &&
                nuevoNombre.trim() !== ""
            ) {
                fila.cells[2].innerText =
                    nuevoNombre;
            }

            let nuevoCorreo = prompt(
                "Editar correo:",
                correoActual
            );

            if (
                nuevoCorreo &&
                nuevoCorreo.trim() !== ""
            ) {
                fila.cells[4].innerText =
                    nuevoCorreo;
            }

            alert("Información actualizada.");

        });

    });

    // ===================================
    // ELIMINAR
    // ===================================

    document.querySelectorAll(".eliminar").forEach(btn => {

        btn.addEventListener("click", () => {

            let fila = btn.closest("tr");

            let nombre =
                fila.cells[2].innerText;

            let confirmar = confirm(
                "¿Desea eliminar a " +
                nombre +
                "?"
            );

            if (confirmar) {

                fila.remove();

                alert(
                    "Usuario eliminado correctamente."
                );

            }

        });

    });

    // ===================================
    // NUEVO PERSONAL
    // ===================================

    const btnAgregar =
        document.getElementById("btnAgregar");

    if (btnAgregar) {

        btnAgregar.addEventListener("click", () => {

            window.location.href =
                "registrar-personal.html";

        });

    }

    // ===============================
// NOTIFICACIONES
// ===============================

const btnNotificacion =
document.querySelector(".notificacion");

if(btnNotificacion){

    btnNotificacion.addEventListener("click", () => {

        alert(
            "No tienes nuevas notificaciones."
        );

    });

}

// ===============================
// CERRAR SESIÓN
// ===============================

const btnCerrarSesion =
document.querySelector(".logout");

if(btnCerrarSesion){

    btnCerrarSesion.addEventListener("click", () => {

        let confirmar = confirm(
            "¿Desea cerrar sesión?"
        );

        if(confirmar){

            window.location.href =
            "login.html";

        }

    });

}

    // ===================================
    // CONTADORES ANIMADOS
    // ===================================

    document.querySelectorAll(".card h2")
        .forEach(numero => {

            let objetivo =
                parseInt(numero.textContent);

            if (isNaN(objetivo)) return;

            let contador = 0;

            const velocidad =
                Math.max(20, 1000 / objetivo);

            const intervalo =
                setInterval(() => {

                    contador++;

                    numero.textContent =
                        contador;

                    if (
                        contador >= objetivo
                    ) {
                        clearInterval(
                            intervalo
                        );
                    }

                }, velocidad);

        });

    // ===================================
    // PERMISOS POR ROL
    // ===================================

    const rolUsuario =
        "administrador";

    // const rolUsuario = "profesor";

    if (
        rolUsuario === "profesor"
    ) {

        if (btnAgregar) {
            btnAgregar.style.display =
                "none";
        }

        document
            .querySelectorAll(
                ".editar, .eliminar"
            )
            .forEach(btn => {

                btn.style.display =
                    "none";

            });

    }

});

// ===============================
// PAGINACIÓN
// ===============================

const paginas =
document.querySelectorAll(".paginacion button");

paginas.forEach(boton => {

    boton.addEventListener("click", () => {

        paginas.forEach(btn => {

            btn.classList.remove(
                "pagina-activa"
            );

        });

        if(
            !boton.querySelector("i")
        ){
            boton.classList.add(
                "pagina-activa"
            );
        }

    });

});