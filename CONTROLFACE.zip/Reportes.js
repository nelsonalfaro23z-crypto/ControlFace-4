/*=========================================================
        CONTROLFACE
        REPORTES.JS
        PARTE 1
=========================================================*/

/*=========================================================
            ESPERAR A QUE CARGUE LA PÁGINA
=========================================================*/

document.addEventListener("DOMContentLoaded", () => {

    console.log("ControlFace iniciado correctamente.");

    /*=====================================================
                OBTENER ELEMENTOS
    =====================================================*/

    const btnPDF = document.getElementById("btnPDF");

    const btnExcel = document.getElementById("btnExcel");

    const btnCerrar = document.querySelector(".cerrar");

    const btnNotificacion = document.querySelector(".notificacion");

    /*=====================================================
                FECHA ACTUAL
    =====================================================*/

    const fecha = new Date();

    console.log("Fecha actual:", fecha);

    /*=====================================================
                EVENTOS
    =====================================================*/

    // Exportar PDF

    btnPDF.addEventListener("click", exportarPDF);

    // Exportar Excel

    btnExcel.addEventListener("click", exportarExcel);

    // Cerrar sesión

    btnCerrar.addEventListener("click", cerrarSesion);

    // Notificaciones

    btnNotificacion.addEventListener("click", mostrarNotificacion);

});


/*=========================================================
            FUNCIÓN PDF
=========================================================*/

function exportarPDF(){

    console.log("Exportando PDF...");

}


/*=========================================================
            FUNCIÓN EXCEL
=========================================================*/

function exportarExcel(){

    console.log("Exportando Excel...");

}


/*=========================================================
            CERRAR SESIÓN
=========================================================*/

function cerrarSesion(){

    const salir = confirm("¿Desea cerrar sesión?");

    if(salir){

        alert("Sesión cerrada correctamente.");

        // Después aquí podrás redirigir al login.
        // window.location.href="login.html";

    }

}


/*=========================================================
            NOTIFICACIÓN
=========================================================*/

function mostrarNotificacion(){

    alert("No hay notificaciones nuevas.");

}
/*=========================================================
        PARTE 2
        GRÁFICA DE BARRAS
=========================================================*/

/*=========================================================
        CREAR GRÁFICA DE BARRAS
=========================================================*/

const graficaBarras = document.getElementById("graficaBarras");

/*
    Verificamos que el canvas exista
    antes de crear la gráfica.
*/

if(graficaBarras){

    new Chart(graficaBarras,{

        type:"bar",

        data:{

            labels:[
                "1°D",
                "2°E",
                "2°M",
                "3°B",
                "1°L"
            ],

            datasets:[

                {

                    label:"Asistencias",

                    data:[
                        96,
                        75,
                        80,
                        70,
                        94
                    ],

                    backgroundColor:[
                        "#4F6EF7",
                        "#4F6EF7",
                        "#4F6EF7",
                        "#4F6EF7",
                        "#4F6EF7"
                    ],

                    borderRadius:10,

                    borderSkipped:false

                }

            ]

        },

        options:{

            responsive:true,

            maintainAspectRatio:false,

            plugins:{

                legend:{
                    display:false
                }

            },

            scales:{

                y:{

                    beginAtZero:true,

                    max:100,

                    ticks:{

                        stepSize:20,

                        color:"#6B7280"

                    },

                    grid:{

                        color:"#ECECEC"

                    }

                },

                x:{

                    ticks:{

                        color:"#374151"

                    },

                    grid:{

                        display:false

                    }

                }

            }

        }

    });

}
/*=========================================================
        PARTE 3
        GRÁFICA CIRCULAR
=========================================================*/

/*=========================================================
        CREAR GRÁFICA CIRCULAR
=========================================================*/

const graficaCircular = document.getElementById("graficaCircular");

/*
    Verificamos que el canvas exista antes
    de crear la gráfica.
*/

if(graficaCircular){

    new Chart(graficaCircular,{

        type:"doughnut",

        data:{

            labels:[

                "Mujeres",
                "Hombres"

            ],

            datasets:[{

                data:[

                    40,
                    60

                ],

                backgroundColor:[

                    "#FF6B81",
                    "#3E52C8"

                ],

                borderColor:[

                    "#FFFFFF",
                    "#FFFFFF"

                ],

                borderWidth:4,

                hoverOffset:12

            }]

        },

        options:{

            responsive:true,

            maintainAspectRatio:false,

            cutout:"65%",

            plugins:{

                legend:{
                    display:false
                },

                tooltip:{

                    enabled:true,

                    callbacks:{

                        label:function(context){

                            return context.label + ": " + context.raw + "%";

                        }

                    }

                }

            },

            animation:{

                animateRotate:true,

                animateScale:true,

                duration:1800

            }

        }

    });

}
/*=========================================================
        PARTE 4
        EXPORTAR PDF Y EXCEL
=========================================================*/

/*=========================================================
        EXPORTAR A PDF
=========================================================*/

function exportarPDF(){

    const { jsPDF } = window.jspdf;

    const documento = new jsPDF();

    documento.setFont("helvetica","bold");
    documento.setFontSize(18);

    documento.text("ControlFace",20,20);

    documento.setFontSize(14);

    documento.text("Reporte General de Asistencia",20,30);

    documento.setFontSize(11);

    documento.text("Fecha: " + new Date().toLocaleDateString(),20,40);

    documento.line(20,45,190,45);

    documento.autoTable({

        startY:55,

        head:[[
            "Sección",
            "Presentes",
            "Tardes",
            "Ausentes",
            "% Asistencia"
        ]],

        body:[

            ["1°D","35","2","1","96%"],
            ["2°E","28","1","2","75%"],
            ["2°M","30","3","3","80%"],
            ["3°B","15","1","2","70%"],
            ["1°L","40","2","1","94%"]

        ],

        theme:"grid",

        headStyles:{

            fillColor:[32,42,107]

        }

    });

    documento.save("Reporte_ControlFace.pdf");

}

/*=========================================================
        EXPORTAR A EXCEL
=========================================================*/

function exportarExcel(){

    const datos=[

        ["Sección","Presentes","Tardes","Ausentes","% Asistencia"],

        ["1°D",35,2,1,"96%"],

        ["2°E",28,1,2,"75%"],

        ["2°M",30,3,3,"80%"],

        ["3°B",15,1,2,"70%"],

        ["1°L",40,2,1,"94%"]

    ];

    const libro = XLSX.utils.book_new();

    const hoja = XLSX.utils.aoa_to_sheet(datos);

    XLSX.utils.book_append_sheet(

        libro,

        hoja,

        "Reportes"

    );

    XLSX.writeFile(

        libro,

        "Reporte_ControlFace.xlsx"

    );

}
/*=========================================================
        PARTE 5
        ANIMACIONES Y FUNCIONES FINALES
=========================================================*/

/*=========================================================
        ANIMACIÓN AL CARGAR LA PÁGINA
=========================================================*/

window.addEventListener("load", () => {

    const contenido = document.querySelector(".contenido");

    contenido.style.opacity = "0";
    contenido.style.transform = "translateY(20px)";

    setTimeout(() => {

        contenido.style.transition = "all .8s ease";

        contenido.style.opacity = "1";

        contenido.style.transform = "translateY(0px)";

    }, 200);

});


/*=========================================================
        MENSAJE DE BIENVENIDA
=========================================================*/

setTimeout(() => {

    console.log("Bienvenido al módulo de Reportes.");

},1000);


/*=========================================================
        EFECTO EN LOS BOTONES
=========================================================*/

const botones = document.querySelectorAll("button");

botones.forEach((boton)=>{

    boton.addEventListener("mouseenter",()=>{

        boton.style.transform="scale(1.03)";

    });

    boton.addEventListener("mouseleave",()=>{

        boton.style.transform="scale(1)";

    });

});


/*=========================================================
        EFECTO EN LAS FILAS DE LA TABLA
=========================================================*/

const filas = document.querySelectorAll("tbody tr");

filas.forEach((fila)=>{

    fila.addEventListener("mouseenter",()=>{

        fila.style.background="#EEF2FF";

    });

    fila.addEventListener("mouseleave",()=>{

        fila.style.background="";

    });

});


/*=========================================================
        RELOJ DEL SISTEMA
=========================================================*/

function actualizarHora(){

    const ahora = new Date();

    console.log(

        "Hora del sistema: " +

        ahora.toLocaleTimeString()

    );

}

setInterval(actualizarHora,60000);


/*=========================================================
        MENSAJE FINAL
=========================================================*/

console.log("Sistema ControlFace listo para utilizar.");